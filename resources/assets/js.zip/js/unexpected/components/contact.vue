<template>
    <div id="contact">
        <div class="entry-content"> 
            <ol class="breadcrumb" style="margin-top: 10px;">
                <li class="breadcrumb-item"><router-link :to="{ name: 'homefrontend'}">Trang chủ</router-link></li>
            </ol>
            <div>
                <h4 class="page-title" style="color:blue">Liên hệ</h4>
            </div>
            <p class="suppbox-name" style="text-align: center;"><span style="font-size: 18pt;"><strong>PHAN PHƯƠNG THÚY</strong></span></p>
            <p class="suppbox-ofs" style="text-align: center;"><strong><span style="font-size: 14pt;">Trưởng Phòng&nbsp;Kinh Doanh</span></strong></p>
            <p class="suppbox-mobile" style="text-align: center;"><span style="color: #000000; font-size: 14pt;">Mobile: <span style="color: #ff0000;"><strong>091.531.9398&nbsp;– 097.989.4596</strong></span></span></p>
            <p class="suppbox-email" style="text-align: center;"><span style="color: #000000; font-size: 14pt;">Email: thuyanh2902.vinhomes@gmail.com</span></p>
        </div>
    </div>
</template>
<style scoped>
.entry-content {
    font-size: 14px;
    line-height: 1.6;
    color: #666;
    padding: 15px 0 30px 0;
    text-align: justify;
}
.entry-content p {
    margin: 0 0 10px;
}
.entry-content p {
    margin: 0 0 10px;
}
.entry-content p {
    margin: 0 0 10px;
}
</style>
