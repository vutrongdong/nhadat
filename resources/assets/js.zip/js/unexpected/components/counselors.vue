<template>
    <div class="supportsec flexslider1 flexslider4 carousel" style="clear:both; padding: 20px;">
        <h3 class="supportsec-title"><img src="http://sangiaodichvinhomes.vn/wp-content/themes/land062-mathsoft/images/icon_supp.png" draggable="false"><span>Chuyên viên tư vấn</span></h3>
        <div class="wrap-supportsec">

        </div>
        <div class="flex-viewport" style="overflow: hidden; position: relative;">
            <div class="supp-box col-lg-6 col-md-6 col-sm-6 sol-xs-12">
                <div class="p-box">
                    <div class='col-lg-4 col-md-4 col-sm-4 sol-xs-12'>
                        <img width="100%" src="http://sangiaodichvinhomes.vn/wp-content/uploads/2017/03/avatar2.jpg" draggable="false">
                    </div>
                    <div class='col-lg-8 col-md-8 col-sm-8 sol-xs-12'>
                        <p class="suppbox-name">PHAN PHƯƠNG THÚY</p>
                        <p class="suppbox-ofs">Trưởng Phòng Kinh Doanh</p>
                        <p class="suppbox-mobile">Mobile: <a href="tel:091.531.9398">091.531.9398</a></p>
                        <p class="suppbox-email">Email: thuyanh2902.vinhomes@gmail.com</p>
                        <p class="suppbox-link"><a href="">Xem chi tiết thêm ... </a></p>
                    </div>
                </div>
            </div> 
            <div class="supp-box col-lg-6 col-md-6 col-sm-6 sol-xs-12">
                <div class="p-box">
                    <div class='col-lg-4 col-md-4 col-sm-4 sol-xs-12'>
                        <img width="100%" src="http://sangiaodichvinhomes.vn/wp-content/uploads/2017/03/avatar2.jpg" draggable="false">
                    </div>
                    <div class='col-lg-8 col-md-8 col-sm-8 sol-xs-12'>
                        <p class="suppbox-name">PHAN PHƯƠNG THÚY</p>
                        <p class="suppbox-ofs">Trưởng Phòng Kinh Doanh</p>
                        <p class="suppbox-mobile">Mobile: <a href="tel:091.531.9398">091.531.9398</a></p>
                        <p class="suppbox-email">Email: thuyanh2902.vinhomes@gmail.com</p>
                        <p class="suppbox-link"><a href="">Xem chi tiết thêm ... </a></p>
                    </div>
                </div>
            </div>  
        </div>
    </div>
</template>
<style scoped>
.flexslider1 {
    position: relative;
    zoom: 1;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    -webkit-box-shadow: '' 0 1px 4px rgba(0, 0, 0, 0.2);
    -moz-box-shadow: '' 0 1px 4px rgba(0, 0, 0, 0.2);
    -o-box-shadow: '' 0 1px 4px rgba(0, 0, 0, 0.2);
    box-shadow: '' 0 1px 4px rgba(0, 0, 0, 0.2);
}

.flexslider, .flexslider1 {
    padding: 0;
}
.supportsec-title {
    font-size: 19px;
    color: #1B5B87;
    display: block;
    padding: 10px 0;
    margin: 10px 0;
    font-weight: bold;
    line-height: 19px;
    border-bottom: 2px solid #1D2964;
}
.wrap-supportsec {
    overflow: hidden;
    margin-left: -5px;
    margin-right: -5px;
    padding-left: 10px;
    padding-right: 10px;
}
.flex-viewport .supp-box .p-box{
    background:#b0d8e5 ;

}
.flex-viewport .supp-box img{
    height: 50%;
    padding: 5px;
}
</style>
