<template>
    <div id="carouselBottom-3d">
        <div class="container" style="margin-top: 100px;">
          <div class="carouselBottom" style="margin: 0 auto">
            <div class="item a">
                <img width="100%" height="100%" src="https://lh3.googleusercontent.com/pmzWT9lp43tWEw3L7D878sVBtwWdNuXFr195sGOQVceptvxQw4SQ1fynnL-Y7Fxl8eS26N01oT1eap6KzXjM2g-1W0k_sD8WXWMdT2z09Y5qcw42sV58OWY2D__2_UR4xUEe0DEWvqU15XIh4eG277hj9lS53wzvnCaJ63BElww10ZL9G1mSiLN98GfsOLApiYhqs5N-VuQ11EHHbcAXtHtAEhbFtL5XqjUdqd-0ridNR4kgr_uhKcIg1d-ULax2P05FXt-1r1cAMgQEn0lxnYAyRDwh70PvDrCB89GaGruZFo57KQB__-SxqoZAJo7Y0qewjDQcz_9gBpzIk6GDjIfhvoJhwLGXkQnsKMNrLXbYULTLr1SjDkPZOI7skLWii8o96MIkKsjxgYQRTj3DJv4RBmZ6jtLdEIjRJ_5jFw15A6veIIVjtarWABuwbSD-02IB0Pmu5Tp1SwrqZKn6nIW4aX1NnH_NwFwjULXMptjwsjrm7PryOZb5ofW15OrQ-VQqAKIfCM94tGK1cCB0XS_VbQC2MRsAaT78a4KmJ9cu6UUHEB_tqh0onZs3dJuR4AznMEcKXG1OlYlhADXy-mom_oDpL5fqdkgIcyipRe1v0Gn3IPlnpX9bIxubRMYJKq5dm-w0crHnWMXXz1Lmhes6=w1301-h468-no" alt="">
            </div>
            <div class="item b">
                <img width="100%" height="100%" src="https://lh3.googleusercontent.com/mGS1zq0RsnzKusxNWABahov_XvfUTN1GgryWPY9ZlcSM3Islr-kij5U4m96ak_vDMGNc_SSJswvF0_2cRNVAKSncGfpEL6gQ9R6aolSKf0TS_fH1WN-bmUhdBPOu20aoZS4nXrmGzn51qa0hWA5A769fAtWK5_aA7mmEq-3l39QWzDHHYdaIiYo-y_kjNWnSg9rbKjNNwwdnsslOb1C2a_Dc2LL_2m_iVDA_NM7oHT7j6b0Hu8z1xFwZMk_HGSN0SFAWHMsAuGOL-tZ4xS6NXZiWU7M_k_skOsI5yx3LfJF5MDFcQAIGKZlyQUUEWfwmsRp0zFaUHEpGN7GX_m-yt0nECGbsrxgqLPMeQN8S3hjqoQS5HqloelpSH4hLdjDIJElu_e6bzjtn2hZQsCfhXhlTX9gQVRn5J-MmHBw-Kh3_28HNd-25R1O1T4AluZ8NcqPEveXxL4_RZ_VnOslPHJk5l3WPWNTAYtEij0NG1039s_sk3spz4zhX7tPm3mAdLxvRNtUDBEmneRbJwBqMOOBqZn6TyHYp-ctnwJVrpGYhiOq2tZ2FH3kMMktsp_q1B1DUx4M94MeGfNFa4m08MlQli5nuEqWLA7iqS8SCvmzHIPST1lBgaSeYxKLVolWPKXxT-dzz--zUYo3CKMnIwysG=w1301-h468-no" alt="">
            </div>
            <div class="item c">
                <img width="100%" height="100%" src="https://lh3.googleusercontent.com/ADeoVvFAITYCqrW14ijaYDEpxEgHxTyfczAL8Kkts58-FraElvLlghsN6U6wEyIHZ3_4pOgpF-RRRBRv5E_hMDnZ-5_pGcW3bUFbuuAhoA1H6-sO96xq9G1csMRL6I4LH_BQ2KI3bXJKU0n6a-G2wQXwVU583PPoo19G3hCo3uwJlBeTFkIfWfZknMBfcujq2m-z2O0Vb_GeoHz8QUcisHClolk_GOITYOZ8LNFGsA8XozBaffSQ0faAG6eS7jqe4-7u8lKBAtl8usJY9KYl5Nk-8YMwEmL8Yu-9j8kBwEW6PgGGn4TyU62uZHruGawmttE63b3tYawMMg8-8YMCc5Ml81mvNBCA31Y1YaROgtB4KJEodiff06PZxXhmqz4oeEN4xus04LA0IxLs6gjbNxXBK05t9H5NTJLUnx-E6S3ITjv_vOha_pKW7L3NBcwFZ3YqxM2vUy9GUqAOfpv6aDKpX6T2ZzjspXZio0N1v37YC4hSMhTsXWeRnj4syUb9iNtghuTxQoLVYjf7BUxZqe3pNgBGtdThbNJaOZMbg8E4AQx5lie7LZgrurMaygUtApdFt65qB-Y6B2o_IJfqUReEixU3D8mnEuLJHyBnVDom-6S0VTtQ59xJ9eXe-bMKgQTvJCLNNBDp7X8O8wG60oEU=w1301-h468-no" alt="">
            </div>
            <div class="item d">
                <img width="100%" height="100%" src="https://lh3.googleusercontent.com/C95fHCpgY1A-EkjgiS6w0IJtDADrb4dL_XFlja7pebWH2yzp3ZpmYk0x2KVBrtC8Gk9dO5XhSgiXCvOIEmxzhOjAw44S0BTKTBX1rM21D5iKEa2JZAJDQe1J0dn_VX_m0dMBj8uWVMRBqcbY3cycq9No2G4aVXbUG_GLY2aohcbA3Ez1VcWa94dET0gMpv6Nw2WUJgZdBRMd4sudVZgfq7QjO5G6tiV15TKqtGtDIERdj-aF1jdjmzvctkCs_V4oxUwuL8IfFYhhnElLygZRjq21DG-jDunr770kwyjWpn3SsW2rIrlZOVayIWDLAl_PtVazbrGO5GtFaRXsjIVRB_psuiRirCXKGjTHcyMVLWhD4DTFbBxrjWiw2nzd2m2rtSE0XrqgLsT9f0x-vNSt2qKhFACVq8guEqc5ZJspzzUo_r7_ftuwHgWnnsF43FmX23MFZJ2VyKBySjkS_QYU3wEC6noRi2I0I72scY2-RQiqyyT0_J775peZyybn4Q7q2RFbqZQQwciPVlv9bwdOtsBxBtyMiAam0Q6plO8buEr5wMVKUuO8_j5ShpSRsWcersC0GA66d_gRc6SyfcS0HMlQXh4omQoNcfapBm75C8ZW7ZgW_F6tsYg_MbwBwLrkpcRlXo3UvojamBHLqT_HFDUn=w1280-h460-no" alt="">
            </div>
            <div class="item e">
                <img width="100%" height="100%" src="https://lh3.googleusercontent.com/oCooJ7Cb_Uc3QuQtFXAwzmFBKfmfVS33TvVqsYxKPYRI3TmuTuwUyC9pjwmc1J3SvHLQ_1IsAwZ2wUJvL37FoI8bk518HHfAqgEi3ogPgpNM1rkJ2TyKfJBxvUkhDyFn4bK_t6bgAD5OlHgV5q4xaYYzSyKedneH_lQThSsNJFhuYhzwjjtPdjdLwheLSZL4ARFm99cUcFjZBGBs_Hcgs-6EYZ_bVke7D-mkgdq98zk-KbyOX8rpMb_pxsWS9Xr8lEG0GAKhu72pjZxSzL7SD_ykWIdrpDqzci1GCC-wiVDwSiQhyXipO_YJbjBtellLmFRLGc92fvHLn9v8UyfyHgKzF1zklofOsizSejkeVeYkJhKEtp9P9Rxi_Bj2tSGmoE9GiVqKdWCKX8i2fLXOrBfOMgJ3h2XNNkB077z8kqch66TUSsIafYlGR5J-D_pv-_Eb-XZMWTVz_4y0IPYKd3v279pyQjR9YKxL93Yg2YiCl4RIA8hLBr9vRhELTS6Xz0YrC--kQbddmbJFMhHEEmRCQ-sjFRrunnOqzWVJxJSWg_V1Z_H2f6fwGdYhHwpbk6WSKaGIl9SIgjcXfMJI2o-nKAAgGA0bMWOmjDggRuTGgxwtvmcjaT7IC6JgPupyGT5f18Qn00xZVWlUujGX3sdY=w1301-h468-no" alt="">
            </div>
            <div class="item f">
                <img width="100%" height="100%" src="https://lh3.googleusercontent.com/HtxJjO4J1G8_2DIMdLTs0LitXQeTNsHOI6ZJW-9W2tIsWwch3P9s20Hc9GLHiWn6PZ4l7yluvcgc5XD-zK7NF13Qd4_B04zaW01qgN5d7k2jAE8u55cnUKFwPLthQ1m3EFK6dqmKynoZRZ4RKBTT30xLbw3nxMDMB6OAKkkt_70kVmZljwe0cNsnYDhRtaY5dTFvRHqQalntRdyAbX1uvwqsUet3OPHpycxpMXbUmKtt3mwwKH6PMyflgNAFMVCjVG6fVofWviMhBYjrDile6Quu4cHCwB-f48ngaPK16fpYqDGVrEd3Bf7HQMDZMgr30LWx_Qw_Jgkoso9oR7B0GEh0sXXXPdS8xJF1lDWFtMBitD3I8C9LnOf1U7_t9YuRkaOFjQJxEeCZlzFmDxWXMIKcjYYTgejjkOrnFCxF-QVEA1M1J0QngUAK3FNDnPMXL38QT2gy1V5kGp5-7LL1kcFDwNxDxAVhXl-fceKSJMPNPEnY2fH_tGfGdUoacBhJAkbqaAybXhwYS_YmZ0PshCAgoC3-7LCskqkTdJvFPPj7cgZeRDADfBv8gluVmVHVZvXnohl7HzJPrTnNr0dmkAS9cnRyr4_U56_MjNkRhj1TdHTWqEMJILo51wRC5vzrBbbfPcdGyp3XDXq-efKxxA31=w1301-h468-no" alt="">
            </div>
        </div>
    </div>
    <div class="clearfix" style="margin-top: 110px;"></div>
    <div id="action" style="width: 108px;position:relative; left:49%; clear: both;">
        <v-btn color="red" icon @click="rotate('d')"><v-icon color="#fff">fas fa-angle-left</v-icon></v-btn>
        <v-btn color="red" icon @click="rotate('n')"><v-icon color="#fff">fas fa-angle-right</v-icon></v-btn>
    </div>
</div>
</template>
<script>
    export default {
        data (){
            return {
                currdeg: 0
            }
        },
        methods:{
            rotate(e){
                var carouselBottom = $(".carouselBottom")
                if(e=="n"){
                    this.currdeg = this.currdeg - 60
                }
                if(e=="d"){
                    this.currdeg = this.currdeg + 60
                }
                carouselBottom.css({
                    "-webkit-transform": "rotateY("+this.currdeg+"deg)",
                    "-moz-transform": "rotateY("+this.currdeg+"deg)",
                    "-o-transform": "rotateY("+this.currdeg+"deg)",
                    "transform": "rotateY("+this.currdeg+"deg)"
                })
            }
        }
    }
</script>
<style scoped>
@media screen and (min-width: 1100px) {
    .container {
      margin: 0 auto;
      width: 300px;
      height: 250px;
      position: relative;
      perspective: 1000px;
  }
  .carouselBottom {
      height: 100%;
      width: 100%;
      position: absolute;
      transform-style: preserve-3d;
      transition: transform 1s;
  }

  .item img{
      display: block;
      position: absolute;
      width: 300px;
      height: 250px;
      opacity: 0.95;
      border-radius: 10px;
  }

  .a {
      transform: rotateY(0deg) translateZ(300px);
  }
  .b {
      transform: rotateY(60deg) translateZ(300px);
  }
  .c {
      transform: rotateY(120deg) translateZ(300px);
  }
  .d {
      transform: rotateY(180deg) translateZ(300px);
  }
  .e {
      transform: rotateY(240deg) translateZ(300px);
  } 
  .f {
      transform: rotateY(300deg) translateZ(300px);
  }
}
/*format for screen max 1000px*/
@media screen and (max-width: 1100px) {
    .container {
      margin: 0 auto;
      width: 250px;
      height: 200px;
      position: relative;
      perspective: 1000px;
  }
  #carouselBottom-3d{
    margin-top: -40px;
  }
  .clearfix{
    margin-top:81px !important;
}
  .carouselBottom {
      height: 100%;
      width: 100%;
      position: absolute;
      transform-style: preserve-3d;
      transition: transform 1s;
  }

  .item img{
      display: block;
      position: absolute;
      width: 250px;
      height: 200px;
      opacity: 0.95;
      border-radius: 10px;
  }

  .a {
      transform: rotateY(0deg) translateZ(250px);
  }
  .b {
      transform: rotateY(60deg) translateZ(250px);
  }
  .c {
      transform: rotateY(120deg) translateZ(250px);
  }
  .d {
      transform: rotateY(180deg) translateZ(250px);
  }
  .e {
      transform: rotateY(240deg) translateZ(250px);
  } 
  .f {
      transform: rotateY(300deg) translateZ(250px);
  }
}
/*format for screen max 850px*/
@media screen and (max-width: 850px) {
    .container {
      margin: 0 auto;
      margin-top: -30px;
      width: 250px;
      height: 200px;
      position: relative;
      perspective: 1000px;
  }
  .carouselBottom {
      height: 100%;
      width: 100%;
      position: absolute;
      transform-style: preserve-3d;
      transition: transform 1s;
  }
  .clearfix{
    margin-top:65px !important;
}
#action{
    left: 48% !important;
}
.item img{
  display: block;
  position: absolute;
  width: 250px;
  height: 200px;
  opacity: 0.95;
  border-radius: 10px;
}

.a {
  transform: rotateY(0deg) translateZ(250px);
}
.b {
  transform: rotateY(60deg) translateZ(250px);
}
.c {
  transform: rotateY(120deg) translateZ(250px);
}
.d {
  transform: rotateY(180deg) translateZ(250px);
}
.e {
  transform: rotateY(240deg) translateZ(250px);
} 
.f {
  transform: rotateY(300deg) translateZ(250px);
}
}
/*format for screen max 732px*/
@media screen and (max-width: 732px) {
    .container {
      margin: 0 auto;
      width: 200px;
      height: 160px;
      position: relative;
      perspective: 1000px;
  }
  .carouselBottom {
      height: 100%;
      width: 100%;
      position: absolute;
      transform-style: preserve-3d;
      transition: transform 1s;
  }
  #carouselBottom-3d{
    margin-left: -38px !important;
}
.clearfix{
    margin-top:42px !important;
}
#action{
    left: 47% !important;
}
.item img{
  display: block;
  position: absolute;
  width: 200px;
  height: 160px;
  opacity: 0.95;
  border-radius: 10px;
}

.a {
  transform: rotateY(0deg) translateZ(200px);
}
.b {
  transform: rotateY(60deg) translateZ(200px);
}
.c {
  transform: rotateY(120deg) translateZ(200px);
}
.d {
  transform: rotateY(180deg) translateZ(200px);
}
.e {
  transform: rotateY(240deg) translateZ(200px);
} 
.f {
  transform: rotateY(300deg) translateZ(200px);
}
}
/*format for screen max 480px*/
@media screen and (max-width: 480px) {
    #carouselBottom-3d{
        margin-left: -45px !important;
    }
    .container {
      margin: 0 auto;
      width: 160px;
      height: 150px;
      position: relative;
      perspective: 1000px;
  }
  .clearfix{
    margin-top:37px !important;
}
#action{
    left: 47% !important;
}
.carouselBottom {
  height: 100%;
  width: 100%;
  position: absolute;
  transform-style: preserve-3d;
  transition: transform 1s;
}

.item img{
  display: block;
  position: absolute;
  width: 170px;
  height: 150px;
  opacity: 0.95;
  border-radius: 10px;
}

.a {
  transform: rotateY(0deg) translateZ(160px);
}
.b {
  transform: rotateY(60deg) translateZ(160px);
}
.c {
  transform: rotateY(120deg) translateZ(160px);
}
.d {
  transform: rotateY(180deg) translateZ(160px);
}
.e {
  transform: rotateY(240deg) translateZ(160px);
} 
.f {
  transform: rotateY(300deg) translateZ(160px);
}
}
/*format for screen max 400px*/
@media screen and (max-width: 400px) {
    #carouselBottom-3d{
        display: none;
    }
}
</style>
