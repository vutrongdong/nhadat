<template>
<div style="margin:0px auto;clear: both;">
    
<!-- Insert to your webpage where you want to display the carousel -->
<div id="amazingcarousel-container-1">
    <div id="amazingcarousel-1" style="display:none;position:relative;width:100%;max-width:1220px;margin:0px auto 0px;">
        <div class="amazingcarousel-list-container">
            <ul class="amazingcarousel-list">
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
                    <div class="amazingcarousel-image"><a href="images/carousel/images/0a6e6dce7b219b7fc230-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" >
                        <img src="https://lh3.googleusercontent.com/R5J1KeKmWrGTptSxZFY3AeP0VB9SvNvVfaOjxs_bGSVINwDbVsbgd6e9vluwyWy6tpCbSDMmw-nTgZum6PXyXRkEIyBchtFaetzFmO_qy1khi0Qx26DFN9d3mSO8UiH8Hikxtms5a62VaVcNU8VnooV5BXplWoNUeX1c4FDGtWPuVBREUJP-S9w8ODeP1NGiQOoCj3vgOPcVukV2JP5rOZaFFFV0tsPPlak7cxhEKr4-KfHlCm4CxDKYHhxboueIjwTZVB5rcj4yNelAM6-8pG3w522qVfOf67CkW8QKt0HHcol5sgJ5nnK6x8vdALSBNk94qMYHgqvwCirXE07H4810I4Lw0jsz3FZTqb8WafzIySVrGOAwzBVE-bnryb38PI07lTu8B5e0tJ__dq-66xI3rLCph6JvGikyMyIrfdAWhlz3_LjZTbQ2ngoJF_2zTD3OdWZUMf2wU4W-Z4bsX6nzxJQY6wNAaolnRk8HM3SHn9Khgs-UibG_g1FIWgDnllfYR07rSd14LB4rhen6iQARYUaboiExMszb4m3qmx-vc6Uw-dP8CqmwEcSU0RkSkITPuLjZVCCLEDxpVdaoOU7KV1EAFxXjuHLbrtj577N-5SgkhSZEfRz5ecrLK7oYCc22nxX7ByzfK6vPbYsUwjfF=w240-h180-no" />
                    </a></div>
                <div class="amazingcarousel-title"></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/carousel/images/2ad1465250bdb0e3e9ac-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" ><img src="https://lh3.googleusercontent.com/ZOvThFeqOfdJNdvhtdolUEI_yNf98M82pHpeJI2ouIVHCjM405S-I-ustgVn9Ydl9SnQbo2mUkhfbetD2z91UTbmnDFhwxrD1giW7xEUzL5Hsg-ed56ZLhTm0mQBOv4neFG2p4fMC8w9fe7bleDX5RPOnKmNk9mzna0OsXo2V0MK3UkaD0oG6tN4RIEbi0SZxluIuUnWXucm1b8LAJH0zbnIwI50iD_k9i9IKp3tsCxTD6gmNRO-aqmesp_4eYJyBMZRt_BbSBzFW-q-MokhFR8N0yqyTutrV5KyewRZ2cpXx-rp0GXAN0KQ5n5SmkqjHT_1PBtm9-sYW2omSEEUS7oXkewoSfk0igGB_2ACC1x8Gcx_jIWH2E5CCWu4Xrr8o-VF-tKzq1dy3VR74RePI8bwzuL0BFYzD8L0VMkaP-Mzwb8_pW7D9PIjKelz2YqpQNC0_L-n4u3_FXSwwFCwdY3s4JiMlZsAohsug03C-3XxG4bVc6-g1c1YH7X0L-VALbHkhcsYAcc2PB_aFMVoKV16qow5U8bMlL1CqpCx5oCv5EMog4MkfqKN2fDP7rnsQXRb5HdM2X_eNGIvJAVtE_0kb_knOUW1bUHuYqdc1cPqttnPCBi2mZL5tomhZZFGA4baE7-zl9ayiMzXIql0JKvo=w240-h180-no" /></a></div>
<div class="amazingcarousel-title"></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/carousel/images/6c93cc3fdad03a8e63c1-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" ><img src="https://lh3.googleusercontent.com/Vxbl41t6SbI5PIbtWQ-yQP9T6Ytaxg4O0aiVQhexdnkSHlG7Ngb0G-SoVWuLv-lHhDV78V8hYQVRj5MU0APuYXl9iYyPQJZ8F1pzcSiQTFx4YZ3EyxfvTHSjtC96WuBh7ymEtZAnSRe2NVdUKEBWm8rSe1jqoaoCOKsUacznOyp4n8rnSHoNRFf6hkVWViYXD8zjgz5i2u0fCNIA_eXp__HfF4SwiZ3sWVFms3CavDnNQdGztciALmmmcCEYDJbN3q5MOXs5BnoUEDYOnh6e-WPKs384qMdEM5sPGaLgxa5YCjlv6CYJluIuNcDpN0pn5VY68hu2CNHEWOWAOJn8RZT1GwF_iItBSgXyhJ9I_UQpR1kMMs16N54Bgia0Ak-sGdb847ZTIsJJJam-mgBxg9nspYQvORq9WTWGxwvQkHuOGMM66yyU-14IpVEXY0uSAsMpRBzZnyALP9s7FcQ79KkCim6PqacpRjYPAkl3cojxjp3JHhWelHiYAiNstcgvg9KE86-UAiO1jqYVbEvgdOikNS9ztuZFL5yKP9fVEi2l7dhB0s-MdhslMMYia3cBaYExBv5qu8GIuwHyPpnsMnfAmzvigZJ3Q97IfjS9SPJ8uh1OFXFTdf83aubKlbSQYym2UmXExOVdM4UMTeUnAugG=w240-h180-no" /></a></div>
<div class="amazingcarousel-title"></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/carousel/images/414ea9f9bf165f480607-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" ><img src="https://lh3.googleusercontent.com/bsKUQNBkWZ0j5_jRbz0rwPUBLgjxOWiRdZlrAtdGmP--ZFna1eRtIs5P3cZJihzmeN76sma_lZuD2inMH-nzblmxSX1VQY5N5YnTbjIt6pnzAff4bSMZfm_uhXNcwb9EEg3Zl3zJAWTuWV9_n3whC2SXIRcVaMV9EB-M8dGsIaTRQPFVT7plObkSMY3W7k-LAEgsbUjCg4J8IkH3IaR1XK4i3CGmnoI4PS515G3WbC2K5jF9drW8q8noG14v-CZp6VQtKjuFcwSg7mzKoLccK_T6QwRNH9s6CxDzNpDmbR0Ir2BRgaxR2LY_neNowfryKa8uYhQ9qzZdTgvoG22WMLGq1z7aqIxduOgdNsLlkheLxC4T8uKJxkNV2IiVuXWAQpGwGDtOYp4MXjlAWSds9y6zcydPZDMmDzPj2fBxZEykCe-mzK_YQd4EMoxQf-PwUjmx5jOTX4USSOHWAAWAnO5EpW-vdC9Eiwsedu_qauNWFJdTaTpddxa1iFIOYRIIw9tPDMHaUl0363KCQ9nJMl-d4F_RwZYhiYud98176kC1P-fRRvtht1bV8mEyHPIrbYNpafF2_KbvBjBETvUAC7GtRqQbh-kYt4LIyyVdLL9fBIZ3KpIxVVqt3H2BleXFJrBdrz_OXmMJkKnUlkMDcAEV=w240-h180-no" /></a></div>
<div class="amazingcarousel-title"></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/carousel/images/533dd96ac88528db7194-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" ><img src="https://lh3.googleusercontent.com/HFmfyCR8hFasQc-fdXkUF0S-C1peAnYurJV-v2IaoLX4bKmJWxB5rvs4sEJjHiYAVxeXOu83YurY1oImaXDt9aF15L1u4ZX3hAX9IPHcJmLO7bRYqtWDl3dqJstKUWbbT6LHobIVjGjWiw6LmyVW0c9k1umvom6QKWf6PgvfkuucP2zy8mHcWvlEz_Up8LeOxTZWK7_vKvgGDLqS7Qe4KP0nFLXQA36D5w9sCQy8oMzlSDE_zqzXQXgpqumag5DBNDD66KvnVadyQp9mjlOCsmxOv7Vm5VxLJyX-Xgh9stk4GWFd5o9wUbghMwb0swzC-CZi9xOBEpZgHHSaRyX5YWERiCiVWyqgxt6YGXVNb0oK9LDFYqIrsMlbap3GEt2yQh7DIJusq3EnySs5yGP1td_pJbIPbSfDI7nGeebAkgBKOXPRD_6EQnU0nEDPMvYUPC-TgZzl2uDjzYmdSAHDFTstejArBnSl90wIZZ48oH4_-1RqSteVmJtAMisnfcXLZ_6prl8zZsOutNWCTc5z7Ia4VTMPXAVutvYsaSODGanKNcp_t1-ddgYHfkRxFTSF6xM5FsuRXNTK-G-HFBlcUqD1po7-hSD3PKMkltNJsWAHBPC2a5J3HcfoIXH6lu19jU_L9qwZgNgAIbpglzrZEdeJ=w240-h180-no" /></a></div>
<div class="amazingcarousel-title"></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/carousel/images/588ab2e8a30743591a16-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" ><img src="https://lh3.googleusercontent.com/j1ivG2AZ7mnsfm6xYRnZ6yli61pKSaQ2vnJYJMRECLoXur6frly_tpdXd_6SYDIT_nPVuCPHyrEeP2H8B4QHZwdrD_i1dUf9xtlmu4wRmH8ksbA8ryNTb4N1ptrY-is2j-NoYruXiqKL9NzzHe8J1MEqAK7uJZaGWnWK9CaATcigqYDdBRPEDQzaqsl4Ytk68HK35FzyoZInYqZy5EjZCilB3fkUE1ifj70IK788aWyf6F8eAXgX__WEIHIG7e23vdpXoIR3fCOPn5fh7A6p5_LmS-Xne-9LOfTsf5YMrnirEn0CcNcaneLYqaSZvFsrNinQyx7uNnDbZo6SAibSdRB_d4tLphNSDpRc4C64K5PT8v_i9IRL9LCrrOgNTf4wQDwTc0qo1AVbTjQJSpupTbkR7AQ49JLv7jqKZeWu_0decTf31WoXkats5pOwdQQSjjhPn7w6OLxwoOarXpxdNz5WgAF7YvU0jBsYSGMhn0lx9RaP86aH5q8K7RFGa4WlYN1oXBSq3tUVH-fj-L69JLoigXzFBMPXcgEx_HpbY-DiFfEuE8eUPmhVI6-7qqEfGsPo1_YL7pSYieLhzoULc6hN4Om7bkfTOuBFwPtIOHFVGW4JR2dNdcfo6lGlLS2J6TQB06NkYQewoTm6tFvb0yXm=w240-h180-no" /></a></div>
<div class="amazingcarousel-title"></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/carousel/images/684ac702d6ed36b36ffc-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" ><img src="https://lh3.googleusercontent.com/0IMm9_QZ1sjsHfgAwFc-tKD8t6y8oNX_2hQidq6u-cyh6-I88PmZhYV2giblqnpNbukQtNEPEx00skhokDF8cUoUHWRbu9sgO6EL0M5pXWpb_JE_dlQGBSFinLdkHIVuI2DNkAxuf-BoM0rUAXFjfWqyTpT4iduzxsRjUL21XFQOxm6fCbW4KUsClEgIyauMNtc_BdsIWialGxxAzZdrAMBwpvGmhPAVKdITSpKOhOElZ2faBORwB981mM8D1D5KqVyL-P6bby0_GhWFq7ClhtCNxJDiF48pEjtxBoo093FwsGwu1FjdYv4UVEo03hQddOkonrDm2z2tKdeKWJmGmCchY4HIjqX6Y1FWNK7Hs8d38SvUG0HVsJdmO7BTHNViBTDxajZV6Ac3RvNxoc6dKPN5IsajuVYZSMRBm20kyMb9suKBX6tN_owRre5ovOyGLExNF6_vLuph2Ps03nsl82CxVKD8wvqBnAFvyW_EOy71OpAnYbNhRSBaEBsB2r_EMDqaGyoMkuf4RufyaLYJbVoat4_8zJbb6pVZ_fBHtSLvQA0MwD1wvm5gD5_rPfEAPYmchd74pbLv2vNnlZKd1GNW6XXVqEK8-30eT7NxsleqkSjvxJaBbo96to9KE4m5vxTgOFtCxlrn2v85ahqvYtph=w240-h180-no" /></a></div>
<div class="amazingcarousel-title"></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/carousel/images/7388d7d5c63a26647f2b-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" ><img src="https://lh3.googleusercontent.com/JkvaRLajJ09oWz6_MGPGm8BpGbTsLyz-cVyG_zz28y3lXYSRRbmkn4nSU-5rSjcpYodJgrrjYZ4ODCRUewD9rsmmR7Hx1fNvBXyYONL0fPjyyoXNV-2jFebo4MM0ZtIKf8vMywYTCq-7Lz6S7rhxVQ6uLZQ2_WQLG1SEcqXJ3ja_NS4wKo0FWnRKay5q6zErA9nnk1vpNq50Nw2afRPA0QzlPFph4zNKmW2abM6M5Vd7qHnjOjEjHs5Z7Gu7mOQyiNBuM0RD3HAqSt2PNsUifrSi3IBsbh7ZNjMvB8RQvxYWLB5JwgMsHzY0OnC_Va7NM54_olOIcHIWE6sgI2n70gqDUbWMg_xJcqj98ir-SwLclkFqaENoYjJdLwE0f0NjdiP_LoimrRcRrBZHohUmoi9n7kc8oAZxqVcqqMPqHMMb_vTCpBOJyFbjk-AzIaw2Q0PEfyMU9xP7nE24AHkUNqdAnL2P0YnHoAvPCM5GwrBowf4gaXya--ra_80Vh69-nUEiiXXHhsO2y45CwVlifFEERA9IN2ogA9ZAK0ZcVB-L0ut8ICi8PSDqZYeXGi1qV1rifLHeJkSFtXYoR0PBUaV9rMPjoYoclbjT8axhcdRz-V0czjGIcU0dWF4nZtHCo6pKFjZAda08PqLQuQPPD9hc=w240-h180-no" /></a></div>
<div class="amazingcarousel-title"></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/carousel/images/595480c8962776792f36-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" ><img src="https://lh3.googleusercontent.com/2JDvQMQcuFilcW0QWfU-0oGQlJ36N_gosvA__KRYOT8UmLgAX-sZ0CWXq4t_-pYQeQtgjAOzAtDpUwK9n6eqOQsEUB2c9aFL6g0fjv9xdXzZCzA9D1tO37QrYaBnXzLmo0rsDp7El-Cae1KF9SMCduHy74xXCABVh96E6_Sc1fOHNhBy9AJBDtAtkZTfGxIPionmQ02txnkg8AfmJ67v9Pewih14iQLI0nLCM6EKpdXRWPsbn-wokcSF5URXxN5BpApgLegoPD_r2h3eRq6Lx-9HAWiKKxMOI_BlzNByhqq_DrIcbtzgPeZIm8xwmi953YYKqm8qkyKsghO01pTHcQKtQ2nzszSifbi0KTeWijGfZmI7SdDd9goB7IS1jA3NwGN7uHq77fEZOwHfEK1OaEo2M3UycjC9Ll2hrztc8yi3VEmb-UYs_pFMu9da8J2-7FKFJW7nnd74kJWxknlEgfGjK3UX4JvjTlf0ioGAgM-k8Zbs7BmvNbg0omWYujVJU0-l28Nj9bCOLgdogbFvVnsKi5apwPUjJMo6jozgdkh3ODkYDE8qd6N7t2rplgfT2jd109WCdpy6nadz-1MBng_c5pzq9pUqbB7IuuzQcnOjGSCk0CulLvx5qDsXGoQ4284mUH2V0OgFJiPL8KTMD3hp=w240-h180-no" /></a></div>
<div class="amazingcarousel-title"></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/carousel/images/b673ef8ff960193e4071-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" ><img src="https://lh3.googleusercontent.com/8-kj7a6ZSKuxyM2dw_UqNg7cJqCNERBddAf1OYRRMNm8H7rj4WN_h3VROrV9PlpYxrCdo7miwuViiqeOLQNJPx2nN3HZ7h7ZoNOBMatVqIPC0MBt-vlrOKmVUagsD5wuL7njL1g5x-9nmVBZvn6So9MwvMurL9SWTq0sOCXY6Bu_9fLUKXi49hZkeva85Vtp27jWZzgn0VdtoaGiMyO-5p880mkiY8MmVY4z-wNOqWOMDzwJ4TrV0UrycC3oFlnJgwHIDFZdByeOwHDc94XEdLkogTwP5lDuVzALmuNOqJXJZHDSbo6vsHzyDmHWjTCQaSrM34CC9gK-1dkf0gn3AMTtEGm-6t2xSdP0ku3jU98cItEFraHgCVj89qZPdI9BHCIzlUPSv0dvP-Z_whpxighR8ADDcTBXifwsoE8sEvMVFmRl8eisZF5XU_BzAGDMEqxwRzZc2P7zPfiVC6mAF3P2odAo4O1OyZxRnPsHeo834Zr8wpqpHRFWgvJ_9x19eR3I1V2sayPJJ4WTFdQjBlZYbSbRZ49qqRmVT9D1P_fWRt8n3fK55dnZ3lPNbs7f5y_LXOsXbgHJWrVa9pX7ILyuUDM_4Gp3l-x41DFmQVfP5czDjdVSJz33oaycRH5NigwBh5acmtA_hu3DmeXEv9_O=w240-h180-no" /></a></div>
<div class="amazingcarousel-title"></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/carousel/images/c5fc19ad0842e81cb153-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" ><img src="https://lh3.googleusercontent.com/HWv7Xpw5zWPPlsMqUkwYOsh70OMUWkwFapNzyEAns9s9De_0IUaFsh6ekGMY70CE7Q2uJ5uWHUn_eVOkrT_4LpxFi_tUh9NL5ssu1JXdA-RsndfEwG-l1aL0Tc6QG9UdoMEK2J08Y0fuTI8Ypq5bNQqhbQHvLtI62lT9Q3bZiHHU3qwqYBdTdgs5KLNb1MTHDGqKwMMBuIECy7bmhpnUtT52OK5rES4NidWzZddaAmxNGEf7XiPXd094ZtWUxOcOOSzZG3UMkKS1XCzfQCdLtI242lWeykbLwUNkp2GxA58zZ4L0f9LtNt1wKsXWFVS9l7G8DL71iRu0wllsEV_rv1fwf_3jgfJJybOGGXiwaOC-UsPWIkRBVrAJ0QTGU9sr7Q7ly2LsSII_lc9txbxQSfh3O0KdqWWQP87DeiWFQbLET6OnOW3w93eY-41pvlSk57GW27f6KXBpDsy3ULec4APJogIBprcKZShS1swPcuckcnWuKX2Cdhqp6z-g8FmmjBG0Icfi0QDzPVLgPuTDuw2VeVwKlxTYwsplrusMiZLnZFu_RorCzIu9z3VLCr34rLglcSo9wB3fEr5lP6XhqePKSk-GYnNGqgX0M5PKI0vaobJEYBaM0xX31lUSLFLPBvtZzqe8H7CymAfn6ZChyWFY=w240-h180-no" /></a></div>
<div class="amazingcarousel-title"></div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image"><a href="images/carousel/images/d22f79bd6f528f0cd643-lightbox.jpg" class="html5lightbox" data-group="amazingcarousel-1" data-width="960" data-height="720" ><img src="https://lh3.googleusercontent.com/06i-wlCTmjaNDK98wPmfC9FvYttATb8zLLltoajhaGBbAgSQJS3SEdtpggj6ZKefNX43FyxneB7upNjBxSP_pr81kY2kHYRoVryII3aoscDIiEExcW25EnObZxkOghDGJdTDODbnJZo_EONVoDXd0fl4Tlq3Zq5cKk-oU_rcLNhqV0zSEUT-vD2VQDfmFv6vpqX37emREBrWb96ipiXF3e7OVZWrg2GZ9FcmkLEB2Khvb8uw0isUTgMtUVL0-VXIfd-wzq3N19hXcPkAjc0WUjbrnBnqTqyt15Qx-wo13J_K6eZpLh7UyZ3mHuJJDwdPIvUOnqIFI27aDrL1TMqQJho30Yo1yzIN8nMQpK7-GkORy9UAAIq9Fcwb37ad0TKIvIthfzZTM-bBHCIbMgghfotsPJxbg-hMXU3L7FMSo97RaWJYJ_HyifxlBh7Srj0M5Zm0MKetE3E2nt7sKZBxYmCTpgWDn5DwOHp-qYwnnG37Su3Sj4Vjgnw7oiiHGt7IrfGQiL12g4xGKThZ8sznZXesUpwt_yzhunFaBPmrVwTqbylPEbRw4nvz4rY9VLPoaGJVQA68Kiv6qUL1wXP77drY5fy67pmloHzKCoYNDoi3byR4HNI3qLsXx8WECkeaTeQGEfYHS5rBGlOAR57q5LQV=w240-h180-no" /></a></div>
<div class="amazingcarousel-title"></div>                    </div>
                </li>
            </ul>
            <div class="amazingcarousel-prev"></div>
            <div class="amazingcarousel-next"></div>
        </div>
        <div class="amazingcarousel-nav"></div>
        <div class="amazingcarousel-engine"><a href="http://amazingcarousel.com">jQuery Image Carousel</a></div>
    </div>
</div>
</div>
</template>
<style>
    @media screen and (max-width: 1000px) {
#amazingcarousel-container-1{
    margin-top:-21px;
    }
} 
   @media screen and (max-width: 600px) {
#amazingcarousel-container-1 .amazingcarousel-prev,.amazingcarousel-next,.amazingcarousel-engine,.amazingcarousel-nav{
    display: none !important;
    }
}
</style>
