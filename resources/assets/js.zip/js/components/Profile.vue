<template>
    <div class="row">
        <div class="col-12">
            <h4 class="page-title">
                Profile
            </h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><router-link :to="{ name: 'home'}">Bảng điều khiển</router-link></li>
                <li class="breadcrumb-item active">Profile</li>
            </ol>
            <p class="clearfix"></p>
        </div>
    </div>
</template>
