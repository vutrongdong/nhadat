import Setting from '../components/Setting';

export default [
    {
        path: '/admin/setting',
        name: 'setting',
        component: Setting
    }
];
