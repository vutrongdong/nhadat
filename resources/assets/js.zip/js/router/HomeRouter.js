import Home from '../components/Home.vue';
import Profile from '../components/Profile.vue';

export default [
    {
        path: 'admin/',
        name: 'home',
        component: Home
    },
    {
        path: 'admin/profile',
        name: 'profile',
        component: Profile
    }
];
